package com.iteasyup.book.mybatistools;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MybatisTools 
{
	public SqlSession mybatis() throws IOException
	{
		//��������
		String resource = "sqlMapConfig.xml";
		InputStream is = Resources.getResourceAsStream(resource);
		// ���ػỰ����
		SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(is);
		// �򿪻Ự����
		SqlSession sqlSession = sqlSessionFactory.openSession();
		return sqlSession;
	}
	
}
