package com.iteasyup.easybug.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;

import com.iteasyup.book.mybatistools.MybatisTools;
import com.iteasyup.easybug.mapper.BugMapper;
import com.iteasyup.easybug.model.Bug;

import sun.nio.cs.ext.MacArabic;

/**
 * Servlet implementation class addbugservlet
 */
public class addbugservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private MybatisTools my = new MybatisTools();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addbugservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		Bug bug = new Bug();
		bug.setBugname(request.getParameter("bugname"));
		bug.setProid(Integer.parseInt(request.getParameter("proid")));
		bug.setState(1);//�����ɵ�BugĬ��Ϊ1
		bug.setContent(request.getParameter("phemenon"));
		bug.setConid(Integer.parseInt(request.getParameter("phetype")));
		bug.setStage(request.getParameter("stage"));
		bug.setUserid(Integer.parseInt(request.getParameter("user")));
		bug.setHaptime(request.getParameter("haptime"));
		SqlSession session = my.mybatis();
		BugMapper mapper = session.getMapper(BugMapper.class);
		int result = mapper.addbug(bug);session.commit();
		if (result>0) {
			request.getRequestDispatcher("prjindex.jsp").forward(request, response);
		}
	}

}
