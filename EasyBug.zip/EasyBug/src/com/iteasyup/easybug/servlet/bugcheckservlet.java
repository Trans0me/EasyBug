package com.iteasyup.easybug.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;

import com.iteasyup.book.mybatistools.MybatisTools;
import com.iteasyup.easybug.mapper.BugMapper;
import com.iteasyup.easybug.model.Bug;

/**
 * Servlet implementation class bugcheckservlet
 */
public class bugcheckservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private MybatisTools my = new MybatisTools();
    //private int proid;private int bugno;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public bugcheckservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int proid = Integer.parseInt(request.getParameter("proid"));
		int bugno = Integer.parseInt(request.getParameter("bugno"));
		request.setAttribute("proid", proid);request.setAttribute("bugno", bugno);
		request.getRequestDispatcher("bugcheck.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int proid = Integer.parseInt(request.getParameter("proid"));
		int bugno = Integer.parseInt(request.getParameter("bugno"));
		Bug bug = new Bug();bug.setBugno(bugno);bug.setProid(proid);
		bug.setConid(Integer.parseInt(request.getParameter("conid")));
		bug.setStruno(Integer.parseInt(request.getParameter("strid")));
		bug.setContime(request.getParameter("contime"));
		bug.setStrtime(request.getParameter("strtime"));
		SqlSession session = my.mybatis();
		BugMapper mapper = session.getMapper(BugMapper.class);
		int result = mapper.modifybug(bug);session.commit();
		if (result>0) {
			request.getRequestDispatcher("prjindex.jsp").forward(request, response);
		}
	}

}
