package com.iteasyup.easybug.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;

import com.iteasyup.book.mybatistools.MybatisTools;
import com.iteasyup.easybug.mapper.BugMapper;
import com.iteasyup.easybug.model.Bug;

/**
 * Servlet implementation class deletebugservlet
 */
public class deletebugservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private MybatisTools my = new MybatisTools();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public deletebugservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//List<Bug> buglist = request.getParameter("buglist");
		int bugno = Integer.parseInt(request.getParameter("bugno"));
		int proid = Integer.parseInt(request.getParameter("proid"));
		Bug bug = new Bug();
		bug.setBugno(bugno);bug.setProid(proid);
		SqlSession session = my.mybatis();
		BugMapper mapper = session.getMapper(BugMapper.class);
		int result = mapper.deletebug(bug);
		session.commit();
		if (result>0) {
			request.getRequestDispatcher("prjindex.jsp").forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
