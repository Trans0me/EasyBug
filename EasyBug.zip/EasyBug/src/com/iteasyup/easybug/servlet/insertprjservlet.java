package com.iteasyup.easybug.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;

import com.iteasyup.book.mybatistools.MybatisTools;
import com.iteasyup.easybug.mapper.EasyBugMapper;
import com.iteasyup.easybug.model.EasyBugPrj;

/**
 * Servlet implementation class insertprjservlet
 */
public class insertprjservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private MybatisTools my = new MybatisTools();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public insertprjservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		EasyBugPrj prj = new EasyBugPrj();
		prj.setPno((int)Math.floor(Math.random()*400+100));
		prj.setPname(request.getParameter("prjname"));
		prj.setStime(request.getParameter("prjstime"));
		prj.setEtime(request.getParameter("prjetime"));
		prj.setLeader(Integer.parseInt(request.getParameter("prjleader")));
		SqlSession session = my.mybatis();
		EasyBugMapper mapper = session.getMapper(EasyBugMapper.class);
		int result = mapper.addprj(prj);
		session.commit();
		if(result>0)
		{
			List<EasyBugPrj> prjlist = new ArrayList<>();
			prjlist.add(prj);
			request.setAttribute("prjlist", prjlist);
		}
		request.getRequestDispatcher("prjindex.jsp").forward(request, response);
	}

}
