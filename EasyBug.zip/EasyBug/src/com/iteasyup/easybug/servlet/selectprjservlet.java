package com.iteasyup.easybug.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;

import com.iteasyup.book.mybatistools.MybatisTools;
import com.iteasyup.easybug.mapper.EasyBugMapper;
import com.iteasyup.easybug.model.EasyBugPrj;

/**
 * Servlet implementation class selectprjservlet
 */
public class selectprjservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private MybatisTools my = new MybatisTools();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public selectprjservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		EasyBugPrj prj = new EasyBugPrj();
		String name = request.getParameter("prjsearch");
		prj.setPname(name);
		SqlSession session = my.mybatis();
		EasyBugMapper mapper = session.getMapper(EasyBugMapper.class);
		List<EasyBugPrj> list = mapper.selectprj(prj);
		request.setAttribute("prjlist", list);
		request.setAttribute("length", list.size());
		request.getRequestDispatcher("prjindex.jsp").forward(request, response);
	}

}
