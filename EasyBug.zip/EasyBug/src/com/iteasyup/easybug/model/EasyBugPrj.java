package com.iteasyup.easybug.model;

public class EasyBugPrj {
	private int pno; // ��Ŀ���
	private String pname; // ��Ŀ����
	private String stime; // ��ʼʱ��
	private String etime; // ��ֹʱ��
	private int leader; // ������id
	public int getPno() {
		return pno;
	}
	public void setPno(int pno) {
		this.pno = pno;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getStime() {
		return stime;
	}
	public void setStime(String stime) {
		this.stime = stime;
	}
	public String getEtime() {
		return etime;
	}
	public void setEtime(String etime) {
		this.etime = etime;
	}
	public int getLeader() {
		return leader;
	}
	public void setLeader(int leader) {
		this.leader = leader;
	}
}
