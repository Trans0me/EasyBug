package com.iteasyup.easybug.model;

public class Bug {
	private int bugno;//BUG��ţ�������
	private String bugname;//bug����
	private int proid;//���ڵ���Ŀ���
	private String content;//��������
	private int pheid;//�������� 
	private String stage;//�����׶Σ�UT CT TT ET��
	private int userid;//������
	private String haptime;//��������
	private int struno;//�Բ���
	private String strtime;//�Բ�ʱ��
	private int strid;//�Բ�����
	private String cause;//ԭ��
	private int conid;//ȷ����
	private String contime;//ȷ��ʱ��
	private int state;//״̬��1.������2.�Բ���3.ȷ����4.�ѹرգ�
	public int getBugno() {
		return bugno;
	}
	public void setBugno(int bugno) {
		this.bugno = bugno;
	}
	public String getBugname() {
		return bugname;
	}
	public void setBugname(String bugname) {
		this.bugname = bugname;
	}
	public int getProid() {
		return proid;
	}
	public void setProid(int proid) {
		this.proid = proid;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getPheid() {
		return pheid;
	}
	public void setPheid(int pheid) {
		this.pheid = pheid;
	}
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getHaptime() {
		return haptime;
	}
	public void setHaptime(String haptime) {
		this.haptime = haptime;
	}
	public int getStruno() {
		return struno;
	}
	public void setStruno(int struno) {
		this.struno = struno;
	}
	public String getStrtime() {
		return strtime;
	}
	public void setStrtime(String strtime) {
		this.strtime = strtime;
	}
	public int getStrid() {
		return strid;
	}
	public void setStrid(int strid) {
		this.strid = strid;
	}
	public String getCause() {
		return cause;
	}
	public void setCause(String cause) {
		this.cause = cause;
	}
	public int getConid() {
		return conid;
	}
	public void setConid(int conid) {
		this.conid = conid;
	}
	public String getContime() {
		return contime;
	}
	public void setContime(String contime) {
		this.contime = contime;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
}
