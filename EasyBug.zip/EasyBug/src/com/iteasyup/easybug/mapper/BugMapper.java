package com.iteasyup.easybug.mapper;

import java.util.List;

import com.iteasyup.easybug.model.Bug;

public interface BugMapper {
	int addbug(Bug bug);
	int modifybug(Bug bug);
	List<Bug> checkbug(Bug bug);
	int deletebug(Bug bug);
	int modifystate(Bug bug);
}
