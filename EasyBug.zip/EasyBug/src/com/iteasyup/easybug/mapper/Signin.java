package com.iteasyup.easybug.mapper;

import com.iteasyup.easybug.model.Users;

public interface Signin {
	Users login(Users user);// ��¼��֤
}
